package com.example.login;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class MedicamentController {

    @FXML
    private TableView<Medicament> medicamentTable;
    @FXML
    private TableColumn<Medicament, String> colDCI;
    @FXML
    private TableColumn<Medicament, String> colNomCommercial;
    @FXML
    private TableColumn<Medicament, String> colDosage;
    @FXML
    private TableColumn<Medicament, Double> colPrixVente;
    @FXML
    private TableColumn<Medicament, Double> colPrixAchat;
    @FXML
    private TableColumn<Medicament, Integer> colQteStock;
    @FXML
    private TableColumn<Medicament, Integer> colFamille;
    @FXML
    private TableColumn<Medicament, String> colForme;
    @FXML
    private TableColumn<Medicament, String> colFournisseur;

    @FXML
    private TextField dciField, nomCommercialField, dosageField, prixVenteField, prixAchatField, qteStockField;

    @FXML
    private Button addButton, updateButton, deleteButton, searchButton, showAllButton, validerButton, refreshButton;
    @FXML
    private TextArea consoleOutput;

    private ObservableList<Medicament> medicamentList = FXCollections.observableArrayList();
    private MedicamentDAO medicamentDAO;
    @FXML
    private ComboBox<Integer> familleComboBox;

    @FXML
    private ComboBox<String> formeComboBox;

    @FXML
    private ComboBox<String> fournisseurComboBox;

    @FXML
    public void initialize() {
        DatabaseConnection dbConnection = new DatabaseConnection();
        Connection connection = dbConnection.getConnection();
        if (connection != null) {
            // Pass the connection to the MedicamentDAO
            medicamentDAO = new MedicamentDAO(connection);

            // Set up table column bindings with Medicament properties
            colDCI.setCellValueFactory(new PropertyValueFactory<>("DCI"));
            colNomCommercial.setCellValueFactory(new PropertyValueFactory<>("nomCommercial"));
            colDosage.setCellValueFactory(new PropertyValueFactory<>("dosage"));
            colPrixVente.setCellValueFactory(new PropertyValueFactory<>("prixUnitVente"));
            colPrixAchat.setCellValueFactory(new PropertyValueFactory<>("prixUnitAchat"));
            colQteStock.setCellValueFactory(new PropertyValueFactory<>("qteStock"));
            colForme.setCellValueFactory(new PropertyValueFactory<>("nomForme"));
            colFamille.setCellValueFactory(new PropertyValueFactory<>("numFamille"));
            colFournisseur.setCellValueFactory(new PropertyValueFactory<>("fournisseurHabituel"));
            familleComboBox.setItems(FXCollections.observableArrayList(medicamentDAO.getAllNumFamilles()));
            formeComboBox.setItems(FXCollections.observableArrayList(medicamentDAO.getAllNomFormes()));
            fournisseurComboBox.setItems(FXCollections.observableArrayList(medicamentDAO.getAllFournisseurs()));

            // Load the list of medicaments from the database
            loadMedicaments();

            // Gestionnaire d'événements pour double-cliquer sur une ligne
            medicamentTable.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2) {  // Vérifie si c'est un double-clic
                    Medicament selectedMed = medicamentTable.getSelectionModel().getSelectedItem();
                    if (selectedMed != null) {
                        // Remplir les champs de texte avec les valeur  s du médicament sélectionné
                        dciField.setText(selectedMed.getDCI());
                        nomCommercialField.setText(selectedMed.getNomCommercial());
                        dosageField.setText(selectedMed.getDosage());
                        prixVenteField.setText(String.valueOf(selectedMed.getPrixUnitVente()));
                        prixAchatField.setText(String.valueOf(selectedMed.getPrixUnitAchat()));
                        qteStockField.setText(String.valueOf(selectedMed.getQteStock()));
                        familleComboBox.setValue(selectedMed.getNumFamille());
                        formeComboBox.setValue(selectedMed.getNomForme());
                        fournisseurComboBox.setValue(selectedMed.getFournisseurHabituel());


                    }
                }
            });
        } else {
            consoleOutput.setText("Erreur de connexion à la base de données : Connexion nulle.");
        }
    }
    @FXML
    private void clearFields() {
        dciField.clear();
        nomCommercialField.clear();
        dosageField.clear();
        prixVenteField.clear();
        prixAchatField.clear();
        qteStockField.clear();

        // Clear the ComboBoxes
        familleComboBox.getSelectionModel().clearSelection();
        formeComboBox.getSelectionModel().clearSelection();
        fournisseurComboBox.getSelectionModel().clearSelection();
    }


    private void loadMedicaments() {
        medicamentList.clear();
        medicamentList.addAll(medicamentDAO.getAllMedicaments());
        medicamentTable.setItems(medicamentList);
    }

    @FXML
    private void addMedicament() {
        try {
            String dci = dciField.getText();

            // Vérifie si la DCI existe déjà
            Medicament existingMed = medicamentDAO.getMedicamentByDCI(dci);
            if (existingMed != null) {
                consoleOutput.setText("Un médicament avec cette DCI existe déjà !");
                return;
            }

            Medicament med = new Medicament(
                    dci,
                    nomCommercialField.getText(),
                    dosageField.getText(),
                    Double.parseDouble(prixVenteField.getText()),
                    Double.parseDouble(prixAchatField.getText()),
                    Integer.parseInt(qteStockField.getText()),
                    familleComboBox.getValue(),
                    formeComboBox.getValue(),
                    fournisseurComboBox.getValue()

            );

            medicamentDAO.addMedicament(med);
            consoleOutput.setText("Médicament ajouté avec succès !");
            loadMedicaments();
        } catch (Exception e) {
            consoleOutput.setText("Erreur d'ajout : " + e.getMessage());
        }
    }


    @FXML
    private void updateMedicament() {
        Medicament selectedMed = medicamentTable.getSelectionModel().getSelectedItem();
        if (selectedMed != null) {
            try {
                // Vérifier si le DCI a été modifié
                if (!dciField.getText().equals(selectedMed.getDCI())) {
                    consoleOutput.setText("Erreur : le DCI ne peut pas être modifié !");
                    return; // On arrête ici
                }

                selectedMed.setNomCommercial(nomCommercialField.getText());
                selectedMed.setDosage(dosageField.getText());
                selectedMed.setPrixUnitVente(Double.parseDouble(prixVenteField.getText()));
                selectedMed.setPrixUnitAchat(Double.parseDouble(prixAchatField.getText()));
                selectedMed.setQteStock(Integer.parseInt(qteStockField.getText()));
                selectedMed.setNumFamille(familleComboBox.getValue());
                selectedMed.setNomForme(formeComboBox.getValue());
                selectedMed.setFournisseurHabituel(fournisseurComboBox.getValue());

                medicamentDAO.updateMedicament(selectedMed);
                consoleOutput.setText("Médicament mis à jour !");
                loadMedicaments();
            } catch (Exception e) {
                consoleOutput.setText("Erreur de mise à jour : " + e.getMessage());
            }
        } else {
            consoleOutput.setText("Sélectionnez un médicament !");
        }
    }


    @FXML
    private void deleteMedicament() {
        Medicament selectedMed = medicamentTable.getSelectionModel().getSelectedItem();
        if (selectedMed != null) {
            medicamentDAO.deleteMedicament(selectedMed);
            consoleOutput.setText("Médicament supprimé !");
            loadMedicaments();
        } else {
            consoleOutput.setText("Sélectionnez un médicament !");
        }
    }

    @FXML
    private void searchMedicament() {
        String searchDCI = dciField.getText();
        if (!searchDCI.isEmpty()) {
            Medicament med = medicamentDAO.getMedicamentByDCI(searchDCI);
            if (med != null) {
                medicamentList.clear();
                medicamentList.add(med);
                medicamentTable.setItems(medicamentList);
                consoleOutput.setText("Médicament trouvé !");
            } else {
                consoleOutput.setText("Aucun médicament trouvé !");
            }
        } else {
            consoleOutput.setText("Entrez un DCI !");
        }
    }

    @FXML
    private void showAllMedicaments() {
        loadMedicaments();
        consoleOutput.setText("Liste des médicaments affichée !");
    }


    @FXML
    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }
}
