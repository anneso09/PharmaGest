package com.example.login;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.sql.Date;


public class UtilisateurController {

    @FXML
    private TableView<Utilisateur> utilisateurTable;
    @FXML
    private TableColumn<Utilisateur, String> colIdentifiant;
    @FXML
    private TableColumn<Utilisateur, String> colPrenom;
    @FXML
    private TableColumn<Utilisateur, String> colNom;
    @FXML
    private TableColumn<Utilisateur, Date> colDatedeNaissance;
    @FXML
    private TableColumn<Utilisateur, Integer> colTelephone;
    @FXML
    private TableColumn<Utilisateur, String> colEmail;
    @FXML
    private TableColumn<Utilisateur, String> colAdresse;
    @FXML
    private TableColumn<Utilisateur, String> colMotdePasse;

    @FXML
    private TextField identifiantField, prenomField, nomField, dateNaissanceField, telephoneField, emailField, adresseField, motPasseField;

    @FXML
    private Button addButton, updateButton, deleteButton, refreshButton;
    @FXML
    private TextArea consoleOutput;

    private ObservableList<Utilisateur> utilisateurList = FXCollections.observableArrayList();
    private UtilisateurDAO utilisateurDAO;

    @FXML
    public void initialize() {
        DatabaseConnection dbConnection = new DatabaseConnection();
        Connection connection = dbConnection.getConnection();
        if (connection != null) {
            utilisateurDAO = new UtilisateurDAO(connection);

            colIdentifiant.setCellValueFactory(new PropertyValueFactory<>("identifiant"));
            colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom_per"));
            colNom.setCellValueFactory(new PropertyValueFactory<>("nom_per"));
            colDatedeNaissance.setCellValueFactory(new PropertyValueFactory<>("date_naissance"));
            colTelephone.setCellValueFactory(new PropertyValueFactory<>("telephone"));
            colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
            colAdresse.setCellValueFactory(new PropertyValueFactory<>("adresse"));
            colMotdePasse.setCellValueFactory(new PropertyValueFactory<>("mot_de_passe"));

            loadUtilisateurs();

            utilisateurTable.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2) {
                    Utilisateur selectedUti = utilisateurTable.getSelectionModel().getSelectedItem();
                    if (selectedUti != null) {
                        identifiantField.setText(selectedUti.getIdentifiant());
                        prenomField.setText(selectedUti.getPrenom_per());
                        nomField.setText(selectedUti.getNom_per());
                        dateNaissanceField.setText(new SimpleDateFormat("yyyy-MM-dd").format(selectedUti.getDate_naissance()));
                        telephoneField.setText(String.valueOf(selectedUti.getTelephone()));
                        emailField.setText(selectedUti.getEmail());
                        adresseField.setText(selectedUti.getAdresse());
                        motPasseField.setText(selectedUti.getMot_de_passe());
                    }
                }
            });
        } else {
            consoleOutput.setText("Erreur de connexion à la base de données : Connexion nulle.");
        }
    }

    private void loadUtilisateurs() {
        utilisateurList.clear();
        utilisateurList.addAll(utilisateurDAO.getAllUtilisateurs());
        utilisateurTable.setItems(utilisateurList);
    }

    @FXML
    private void addUtilisateur() {
        try {
            String identifiant = identifiantField.getText();

            Utilisateur existingUti = utilisateurDAO.getUtilisateurByIdentifiant(identifiant);
            if (existingUti != null) {
                consoleOutput.setText("Un utilisateur avec cet identifiant existe déjà !");
                return;
            }

            java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateNaissanceField.getText());
            Date sqlDate = new Date(utilDate.getTime()); // java.sql.Date

            Utilisateur uti = new Utilisateur(
                    identifiant,
                    nomField.getText(),
                    prenomField.getText(),
                    sqlDate,
                    Integer.parseInt(telephoneField.getText()),
                    emailField.getText(),
                    adresseField.getText(),
                    motPasseField.getText()
            );


            utilisateurDAO.addUtilisateur(uti);
            consoleOutput.setText("Utilisateur ajouté avec succès !");
            loadUtilisateurs();
        } catch (Exception e) {
            consoleOutput.setText("Erreur d'ajout : " + e.getMessage());
        }
    }

    @FXML
    private void updateUtilisateur() {
        Utilisateur selectedUti = utilisateurTable.getSelectionModel().getSelectedItem();
        if (selectedUti != null) {
            try {
                // Vérifier si l'identifiant a été modifié
                if (!identifiantField.getText().equals(selectedUti.getIdentifiant())) {
                    consoleOutput.setText("Erreur : l'identifiant ne peut pas être modifié !");
                    return; // Stoppe ici
                }

                selectedUti.setPrenom_per(prenomField.getText());
                selectedUti.setNom_per(nomField.getText());
                java.util.Date utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateNaissanceField.getText());
                Date sqlDate = new Date(utilDate.getTime()); // java.sql.Date
                selectedUti.setDate_naissance(sqlDate);
                selectedUti.setTelephone(Integer.parseInt(telephoneField.getText()));
                selectedUti.setEmail(emailField.getText());
                selectedUti.setAdresse(adresseField.getText());
                selectedUti.setMot_de_passe(motPasseField.getText());

                utilisateurDAO.updateUtilisateur(selectedUti);
                consoleOutput.setText("Utilisateur mis à jour !");
                loadUtilisateurs();
            } catch (Exception e) {
                consoleOutput.setText("Erreur de mise à jour : " + e.getMessage());
            }
        } else {
            consoleOutput.setText("Sélectionnez un utilisateur !");
        }
    }


    @FXML
    private void deleteUtilisateur() {
        Utilisateur selectedUti = utilisateurTable.getSelectionModel().getSelectedItem();
        if (selectedUti != null) {
            utilisateurDAO.deleteUtilisateur(selectedUti);
            consoleOutput.setText("Utilisateur supprimé !");
            loadUtilisateurs();
        } else {
            consoleOutput.setText("Sélectionnez un utilisateur !");
        }
    }
    @FXML
    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }
    @FXML
    private void clearFields() {
        identifiantField.clear();
        prenomField.clear();
        nomField.clear();
        telephoneField.clear();
        dateNaissanceField.clear();
        emailField.clear();
        adresseField.clear();
        motPasseField.clear();


    }

}
