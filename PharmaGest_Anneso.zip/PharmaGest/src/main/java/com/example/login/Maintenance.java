package com.example.login;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Maintenance {
    public void MedicamentOnAction(ActionEvent actionEvent) {
        String MedicamentFXML = "Medicament.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(MedicamentFXML));
        try {
            Parent MedicamentParent = loader.load();
            Scene MedicamentScene = new Scene(MedicamentParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(MedicamentScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + MedicamentFXML, e);
        }
    }
    public void UtilisateurOnAction(ActionEvent actionEvent) {
        String utilisateurFXML = "utilisateur.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(utilisateurFXML));
        try {
            Parent utilisateurParent = loader.load();
            Scene utilisateurScene = new Scene(utilisateurParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(utilisateurScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + utilisateurFXML, e);
        }
    }


    public void RetourOnAction(ActionEvent actionEvent) {
        String dashboardFXML = "Dashboard.fxml";
        FXMLLoader loader = new FXMLLoader(getClass().getResource(dashboardFXML));
        try {
            Parent dashboardParent = loader.load();
            Scene dashboardScene = new Scene(dashboardParent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Impossible de charger le fichier FXML : " + dashboardFXML, e);
        }
    }
}
