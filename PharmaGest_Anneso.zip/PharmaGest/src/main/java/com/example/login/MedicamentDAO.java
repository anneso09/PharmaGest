package com.example.login;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicamentDAO {

    // Assumer que la connexion est déjà gérée par une classe de connexion partagée
    private Connection connection;

    public MedicamentDAO(Connection connection) {
        this.connection = connection; // Utilisation de la connexion partagée
    }


    // Récupérer tous les médicaments de la base de données
    public List<Medicament> getAllMedicaments() {
        List<Medicament> medicaments = new ArrayList<>();
        String query = "SELECT * FROM medicament"; // Change selon ton schéma

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                // Vérifie que les noms de colonnes correspondent à ceux de ta base de données
                Medicament med = new Medicament(
                        rs.getString("DCI"),  // Assure-toi que le nom de la colonne DCI est correct
                        rs.getString("nom_commercial"),  // nom_commercial dans ta table
                        rs.getString("dosage"),
                        rs.getDouble("prixUnit_vente"),  // prixUnit_vente dans ta table
                        rs.getDouble("prixUnit_achat"),  // prixUnit_achat dans ta table
                        rs.getInt("qte_Stock"),  // qte_Stock dans ta table
                        rs.getInt("num_famille"), // num_famille fait référence à une autre table famille
                        rs.getString("nom_forme"), // nom_forme fait référence à une autre table forme
                        rs.getString("fournisseur_habituel") // fournisseur_habituel fait référence à une autre table fournisseur
                );
                medicaments.add(med);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicaments;
    }
    public Utilisateur getUtilisateurByIdentifiant(String identifiant) {
        Utilisateur utilisateur = null;
        String query = "SELECT * FROM utilisateur WHERE identifiant = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, identifiant);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                utilisateur = new Utilisateur(
                        rs.getString("identifiant"),
                        rs.getString("prenom_per"),
                        rs.getString("nom_per"),
                        rs.getDate("date_naissance"),
                        rs.getInt("telephone"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getString("mot_de_passe")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Tu peux aussi faire un `System.out.println(e.getMessage());`
        }

        return utilisateur;
    }

    // Ajouter un médicament dans la base de données
    public void addMedicament(Medicament medicament) {
        String query = "INSERT INTO medicament (DCI, nom_commercial, dosage, prixUnit_vente, prixUnit_achat, qte_Stock, num_famille, nom_forme, fournisseur_habituel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, medicament.getDCI());
            stmt.setString(2, medicament.getNomCommercial());
            stmt.setString(3, medicament.getDosage());
            stmt.setDouble(4, medicament.getPrixUnitVente());
            stmt.setDouble(5, medicament.getPrixUnitAchat());
            stmt.setInt(6, medicament.getQteStock());
            stmt.setInt(7, medicament.getNumFamille());
            stmt.setString(8, medicament.getNomForme());
            stmt.setString(9, medicament.getFournisseurHabituel());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Mettre à jour un médicament dans la base de données
    public void updateMedicament(Medicament medicament) {
        String query = "UPDATE medicament SET nom_commercial = ?, dosage = ?, prixUnit_vente = ?, prixUnit_achat = ?, qte_Stock = ?, num_famille = ?, nom_forme = ?, fournisseur_habituel = ? WHERE DCI = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, medicament.getNomCommercial());
            stmt.setString(2, medicament.getDosage());
            stmt.setDouble(3, medicament.getPrixUnitVente());
            stmt.setDouble(4, medicament.getPrixUnitAchat());
            stmt.setInt(5, medicament.getQteStock());
            stmt.setInt(6, medicament.getNumFamille());
            stmt.setString(7, medicament.getNomForme());
            stmt.setString(8, medicament.getFournisseurHabituel());
            stmt.setString(9, medicament.getDCI());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Supprimer un médicament de la base de données
    public void deleteMedicament(Medicament medicament) {
        String query = "DELETE FROM medicament WHERE DCI = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, medicament.getDCI());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Rechercher un médicament par son DCI
    public Medicament getMedicamentByDCI(String dci) {
        String query = "SELECT * FROM medicament WHERE DCI = ?";
        Medicament medicament = null;

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, dci);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                medicament = new Medicament(
                        rs.getString("DCI"),
                        rs.getString("nom_commercial"),  // nom_commercial dans ta table
                        rs.getString("dosage"),
                        rs.getDouble("prixUnit_vente"),  // prixUnit_vente dans ta table
                        rs.getDouble("prixUnit_achat"),  // prixUnit_achat dans ta table
                        rs.getInt("qte_Stock"),  // qte_Stock dans ta table
                        rs.getInt("num_famille"), // num_famille fait référence à une autre table famille
                        rs.getString("nom_forme"), // nom_forme fait référence à une autre table forme
                        rs.getString("fournisseur_habituel") // fournisseur_habituel fait référence à une autre table fournisseur
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicament;
    }
    public List<Integer> getAllNumFamilles() {
        List<Integer> familles = new ArrayList<>();
        String query = "SELECT DISTINCT num_famille FROM famille"; // ou autre table
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                familles.add(rs.getInt("num_famille"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return familles;
    }
    public List<String> getAllNomFormes() {
        List<String> formes = new ArrayList<>();
        String query = "SELECT DISTINCT nom_forme FROM forme"; // ou autre table
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                formes.add(rs.getString("nom_forme"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return formes;
    }
    public List<String> getAllFournisseurs() {
        List<String> fournisseurs = new ArrayList<>();
        String query = "SELECT DISTINCT nom FROM fournisseur"; // ou autre table
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                fournisseurs.add(rs.getString("nom"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fournisseurs;
    }


}