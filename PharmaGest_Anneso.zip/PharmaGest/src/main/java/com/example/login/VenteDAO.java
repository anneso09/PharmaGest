package com.example.login;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class VenteDAO {
        public List<Vente> getVentes() {
            List<Vente> ventes = new ArrayList<>();
            String sql = "SELECT num_vente, date_vente, status, montant, utilisateur_id FROM vente";
            try (Connection conn = new DatabaseConnection().getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {


                while (rs.next()) {
                    Vente vente = new Vente(
                            rs.getInt("num_vente"),
                            rs.getDate("date_vente"),
                            rs.getString("status"),
                            rs.getDouble("montant"),
                            rs.getInt("utilisateur_id")
                    );
                    ventes.add(vente);
                }

            } catch (Exception e) {
                System.out.println("Erreur lors de l'exécution de la requête SQL : " + e.getMessage());
                e.printStackTrace();
            }

            return ventes;
        }
    public boolean validerVente(int numVente) {
        String updateSql = "UPDATE vente SET status = 'Terminé' WHERE num_vente = ?";

        try (Connection conn = new DatabaseConnection().getConnection();
             PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {

            int rowsUpdated;

            updateStmt.setInt(1, numVente);
            rowsUpdated = updateStmt.executeUpdate();

            return rowsUpdated > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
//    public boolean validerVente(int numVente) {
//        String updateSql = "UPDATE vente SET status = 'Terminé' WHERE num_vente = ?";
//
//        try (Connection conn = new DatabaseConnection().getConnection();
//             PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
//
//            int rowsUpdated;
//
//            updateStmt.setInt(1, numVente);
//            rowsUpdated = updateStmt.executeUpdate();
//
//            return rowsUpdated > 0;
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
}



