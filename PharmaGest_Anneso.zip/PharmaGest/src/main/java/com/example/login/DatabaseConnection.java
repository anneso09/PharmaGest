package com.example.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public Connection databaselink;

    public Connection getConnection() {
        String databaseName ="PharmaGestBD";
        String databaseUser="postgres";
        String databasePassword="290604";
        String url="jdbc:postgresql://localhost:5432/" + databaseName;

        try {
            Class.forName("org.postgresql.Driver");
            databaselink = DriverManager.getConnection(url, databaseUser, databasePassword);
            System.out.println("Connexion à la base de données réussie !");
        } catch (Exception e) {
            System.err.println("Erreur de connexion à la base de données !");
            e.printStackTrace();
            databaselink = null;
        }
        return databaselink;
    }
}




//        String databaseName ="supercaranneso_pharmagestdb";
//        String databaseUser="supercaranneso_admin";
//        String databasePassword="annesoDB";
//        String url="jdbc:postgresql://postgresql-supercaranneso.alwaysdata.net:5432/" + databaseName;