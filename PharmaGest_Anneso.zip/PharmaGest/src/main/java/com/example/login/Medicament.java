package com.example.login;

public class Medicament {
    private String DCI;
    private String nomCommercial;
    private String dosage;
    private double prixUnitVente;
    private double prixUnitAchat;
    private int qteStock;
    private int numFamille;
    private String nomForme;
    private String fournisseurHabituel;

    public Medicament(String DCI, String nomCommercial, String dosage, double prixUnitVente, double prixUnitAchat, int qteStock, int numFamille, String nomForme, String fournisseurHabituel) {
        this.DCI = DCI;
        this.nomCommercial = nomCommercial;
        this.dosage = dosage;
        this.prixUnitVente = prixUnitVente;
        this.prixUnitAchat = prixUnitAchat;
        this.qteStock = qteStock;
        this.numFamille = numFamille;
        this.nomForme = nomForme;
        this.fournisseurHabituel = fournisseurHabituel;
    }

    // Getters and Setters

    public String getDCI() {
        return DCI;
    }

    public void setDCI(String DCI) {
        this.DCI = DCI;
    }

    public String getNomCommercial() {
        return nomCommercial;
    }

    public void setNomCommercial(String nomCommercial) {
        this.nomCommercial = nomCommercial;
    }

    public String getDosage() {
        return dosage;
    }

    public void setDosage(String dosage) {
        this.dosage = dosage;
    }

    public double getPrixUnitVente() {
        return prixUnitVente;
    }

    public void setPrixUnitVente(double prixUnitVente) {
        this.prixUnitVente = prixUnitVente;
    }

    public double getPrixUnitAchat() {
        return prixUnitAchat;
    }

    public void setPrixUnitAchat(double prixUnitAchat) {
        this.prixUnitAchat = prixUnitAchat;
    }

    public int getQteStock() {
        return qteStock;
    }

    public void setQteStock(int qteStock) {
        this.qteStock = qteStock;
    }

    public int getNumFamille() {
        return numFamille;
    }

    public void setNumFamille(int numFamille) {
        this.numFamille = numFamille;
    }

    public String getNomForme() {
        return nomForme;
    }

    public void setNomForme(String nomForme) {
        this.nomForme = nomForme;
    }

    public String getFournisseurHabituel() {
        return fournisseurHabituel;
    }

    public void setFournisseurHabituel(String fournisseurHabituel) {
        this.fournisseurHabituel = fournisseurHabituel;
    }
}
